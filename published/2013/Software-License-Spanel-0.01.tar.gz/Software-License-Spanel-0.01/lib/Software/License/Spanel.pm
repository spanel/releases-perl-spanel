package Software::License::Spanel;

use strict;
use warnings;

our $VERSION = '0.01'; # VERSION

use base 'Software::License';

sub name { 'Spanel License' }
sub url  { 'http://spanel.info/license/' }
sub meta_name  { 'spanel' }
sub meta2_name { 'spanel' }

1;
# ABSTRACT: The Spanel License



=pod

=head1 NAME

Software::License::Spanel - The Spanel License

=head1 VERSION

version 0.01

=head1 AUTHOR

Steven Haryanto <steven@spanel.info>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2013 by Steven Haryanto.  No
license is granted to other entities.

=cut


__DATA__
__LICENSE__
Spanel Software License Agreement

IMPORTANT -- READ CAREFULLY. By installing, copying, or otherwise using the
Software, you are agreeing to be bound by the terms of this EULA, including the
WARRANTY DISCLAIMERS, LIMITATIONS OF LIABILITY, and TERMINATION PROVISIONS. If
you do not agree to the terms of this EULA do not install or use the Software.

LICENSE TERMS

1. The Software is supplied by Steven Haryanto and is licensed, not sold, under
   the terms of this EULA and Steven Haryanto reserves all rights not expressly
   granted to you. Steven Haryanto retains the ownership of the Software.

2. Software License:

   a. Steven Haryanto grants you a license to use one copy of the Software. You
      may not modify or disable any licensing or control features of the
      Software.

   b. This Software is licensed to operate on only one server.

   c. The Software is licensed only to you. You may not rent, lease,
      sub-license, sell, assign, pledge, transfer or otherwise dispose of the
      Software, on a temporary or permanent basis, without the prior written
      consent of Steven Haryanto. (For the avoidance of doubt, this licence is
      only granted to one person/company and if more than one person/company
      wishes to use the Software, each company must purchase a separate
      license).

3. License Restrictions:

   a. By accepting this EULA you are agreeing not to reverse engineer,
      decompile, or disassemble the Software Application, except and only to the
      extent that such activity is expressly permitted by applicable law
      notwithstanding this limitation.

   b. You are the exclusive licensee of the Software and sharing any source code
      of the Software with any individual or entity is a violation of copyright
      laws and international treaties and cause for license termination.

   c. Modifying any portion of the Software source code or asking any individual
      or entity to modify the Software source code other than Steven Haryanto is
      a violation of copyright laws and international treaties and cause for
      license termination.

   d. If you upgrade the Software to a higher version of the Software, this EULA
      is terminated and your rights shall be limited to the EULA associated with
      the higher version.

4. Proprietary Rights: All title and copyrights in and to the Software
   (including, without limitation, any images, photographs, animations, video,
   audio, music, text, and "applets" incorporated into the Software
   Application), the accompanying media and printed materials, and any copies of
   the Software are owned by Steven Haryanto. The Software is protected by
   copyright laws and international treaty provisions. Therefore, you must treat
   the Software like any other copyrighted material, subject to the provisions
   of this EULA.

5. Termination Rights:

   a. Without prejudice to any other rights, Steven Haryanto may terminate this
      EULA if you fail to comply with the terms and conditions of this EULA. In
      such event, you must destroy all copies of the Software and all of its
      component parts, and Steven Haryanto may suspend or deactivate your use of
      the Software with or without notice.

   b. Steven Haryanto may terminate this EULA if you become subject to an
      administration order; a receiver or administrative receiver or similar is
      appointed over, or an encumbrancer takes possession of, any of your
      property or assets; you enter into an arrangement or composition with your
      creditors, you cease or threaten to cease to carry on business, you become
      insolvent or bankrupt, or cease to be able to pay your debts as they fall
      due;

   c. Steven Haryanto may terminate this EULA if you fail to pay your monthly
     fee to him and he files a final written notice on you and the outstanding
     sums due under this EULA still remain unpaid 5 days after the service of
     the notice.

6. Export Control: You may not export or re-export the Software or any copy or
   adaptation of the Software in violation of any applicable laws or
   regulations.

7. Steven Haryanto does not warrant that the operation of Spanel Software will
   be uninterrupted or error free. Spanel Software may contain third-party
   functions or may have been subject to incidental use.

8. LIMIT of Liability:

   a. Steven Haryanto is not responsible for problems resulting from improper or
      inadequate maintenance or configuration; software or interface routines or
      functions NOT developed by him; unauthorized specifications for the
      Software; improper site preparation or maintenance; Beta Software;
      encryption mechanisms or routines.

   b. Good data processing procedure dictates that any program be thoroughly
      tested with non-critical data before relying on it. You must assume the
      entire risk of using the Software. IN NO EVENT WILL STEVEN HARYANTO OR HIS
      SUPPLIERS BE LIABLE FOR DIRECT, SPECIAL, INCIDENTAL, CONSEQUENTIAL
      (INCLUDING LOST PROFIT OR LOST SAVINGS) OR OTHER DAMAGE WHETHER BASED IN
      CONTRACT, TORT, OR OTHERWISE EVEN IF A REPRESENTATIVE FOR SPANEL SOFTWARE
      HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES, OR FOR ANY CLAIM BY
      ANY THIRD PARTY.

9. If the above clause 8 is deemed to be unenforceable by a court or other body
   of competent jurisdiction and Steven Haryanto is found to be liable to you
   for direct losses under this EULA, then Steven Haryanto's liability shall be
   limited to $10,000 (ten thousand US dollars) for any one event or a series of
   connected events.

10. Submissions: Should you decide to transmit to Steven Haryanto by any means
    or by any media any information (including, without limitation, ideas,
    concepts, or techniques for new or improved services and products), whether
    as information, feedback, data, questions, comments, suggestions, or the
    like, you agree such submissions are unrestricted and shall be deemed
    non-confidential and you automatically grant Steven Haryanto and his assigns
    a non-exclusive, royalty-free, worldwide, perpetual, irrevocable license,
    with the right to sublicense, to use, copy, transmit, distribute, create
    derivative works of, display, and perform the same.

11. Distribution and Backups:

    a. DISTRIBUTION OF THE REGISTERED VERSION OF THE Software IS STRICTLY
       PROHIBITED and is a violation of copyright laws and international
       treaties punishable by severe criminal and civil penalties.

    b. You may make copies of the Registered Version of the Software for backup
       purposes only. All backup copies must be an exact copy of the original
       Software.

12. Refunds Policy: Refunds are only issued for software failure. Refunds are
    not issued for server failure/issues, lack of features or if your server
    does not meet the Software Requirements. Refunds are determined on
    individual circumstances and only issued once our technical staff determine
    that Spanel has a fault causing it to not run on your server. Installation
    charges are not refundable under any circumstances. Refunds are not
    available after 1 month from purchase date.

13. If any provision of this EULA shall be prohibited by law or adjudged by a
    court to be unlawful, void or unenforceable such provision shall to the
    extent required be severed from this EULA and rendered ineffective as far as
    possible without modifying the remaining provisions of this EULA and shall
    not in any way affect any other circumstances of or the validity or
    enforcement of this EULA.

14. Steven Haryanto undertakes to comply with the provisions of the Data
    Protection Act 1998 and any related legislation in so far as the same
    relates to the provision of the Software and related support services by
    Steven Haryanto to you.

    Your name, address and other personal information as well as any personal
    data you supply to Steven Haryanto in order for him to provide the Software
    and related services related to you will be stored by Steven Haryanto on his
    computer system and may be made available to his staff and related third
    parties as required to allow the provision of support and any related
    services to be completed. Any third party that receives personal data from
    Steven Haryanto is under an obligation to process such personal data in line
    with the Data Protection Act 1998.

15. Each party irrevocably agrees that the courts of the country of Indonesia
    shall have exclusive jurisdiction to resolve any controversy or claim of
    whatever nature arising out of or in relation to this EULA and the place of
    performance of this EULA shall be Indonesia and that the laws of that
    country shall govern such controversy or claim.
